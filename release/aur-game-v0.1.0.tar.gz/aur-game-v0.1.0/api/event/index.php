<?php

include '../../bot/config.php';
include '../../bot/functions.php';

echo 'ok';